from flask import Blueprint, render_template, request, session, redirect
from app import resources, Token, Link, save_history
import json
import os


if len(Token.query().all()) == 0:
	token = Token(token='ZEKI_ZED', admin=True)
	token.save()

''' Utils '''

blueprint = Blueprint('auth', __name__, url_prefix='/auth')


@blueprint.route('/')
def index():
	if check_session(session, is_admin=True):
		save_history('auth.index', 'Redirect to settings', session)
		return redirect('/auth/access_control')
	save_history('auth.index', '')
	return redirect('/auth/login')


@blueprint.route('/login', methods=['GET', 'POST'])
def login():
	if request.method == 'POST':
		token = request.form.get('token', '')
		tokens = Token.query().filter(token=token).all()
		if len(tokens) == 0:
			save_history('auth.login', 'Invalid Login {}'.format(token))
			return render_template('auth/login.html', **resources, error=True)
		else:
			token = tokens[0]
			session['owner'] = token.token
			save_history('auth.login', 'Logged in as {}'.format(token.token), session)
			return redirect('/')
	return render_template('auth/login.html', **resources, error=False)


@blueprint.route('/logout')
def logout():
	if session.get('owner') is not None:
		save_history('auth.logout', 'Logged out', session)
		del session['owner']
	return redirect('/auth/login')


@blueprint.route('/tokens', methods=['GET', 'POST'])
def tokens():
	if not check_session(session, is_admin=True):
		save_history('auth.tokens', 'Unauthorized Access',)
		return json.dumps({
			"status": "Unauthorized",
			"message": "You are not authorized to use this api"
		})
	config = {}
	if request.method == 'GET':
		tokens = []
		for token in Token.query().all():
			tokens.append({
				'token': token.token,
				'is_admin': token.admin
			})
		config['tokens'] = tokens
		config['status'] = 'success'
		save_history('auth.tokens', 'Load Tokens', session)
		return json.dumps(config)
	else:
		tokens = json.loads(request.form.get('tokens'))
		token_tokens = [token['token'] for token in tokens]
		for token in tokens:
			the_tokens = Token.query().filter(token=token['token']).all()
			if len(the_tokens) == 0:
				new_token = Token()
				new_token.token = token['token']
				new_token.admin = token['is_admin']
				new_token.save()
			if len(the_tokens) == 1 and the_tokens[0].admin != token['is_admin']:
				the_tokens[0].admin = token['is_admin']
				the_tokens[0].save()
		for token in Token.query().all():
			if token.token not in token_tokens:
				Link.query().filter(owner=token.token).delete()
				if os.path.exists('static/proxy_dl/' + token.token):
					for file in os.scandir('static/proxy_dl/' + token.token):
						if file.is_file():
							os.remove(file.path)
						else:
							[os.remove(file.path) for file in os.scandir(file.path)]
							os.removedirs(file.path)
					os.removedirs('static/proxy_dl/' + token.token)
				token.delete()
		fp = open('auth.json', 'w+')
		json.dump(config, fp)
		fp.flush()
		fp.close()
		save_history('auth.tokens', 'Saved Tokens', session)
		return json.dumps({'status': 'success'})


@blueprint.route('/access_control')
def access_control():
	if not check_session(session, is_admin=True):
		save_history('auth.settings', 'Unauthorized Access')
		return redirect('/auth/login')
	save_history('auth.settings', 'Load Settings', session)
	return render_template('auth/settings.html', **resources)


def check_session(session, is_admin=False):
	owner = session.get('owner')
	if owner is None:
		return False
	tokens = Token.query().filter(token=owner)
	if is_admin:
		tokens = tokens.filter(admin=True)
	if len(tokens.all()) > 0:
		return True
	return False
