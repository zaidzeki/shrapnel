"use strict";
var checking_progress = true;
var ignore_count = 0;

function download_url() {
    console.log('Download Url');
    $.ajax({
        url:'/proxy_dl/download',
        type:'post',
        data:{
            'url':$('[name=\'url\']').val(),
            'name':$('[name=\'filename\']').val()
        },
        success:function (data) {
            data = JSON.parse(data);
            if (data['status'] === 'success') {
                toast('Download added successfully');
                $(':input[name=\'url\']').val('');
                $(':input[name=\'filename\']').val('');
                if (!checking_progress) {
                    checking_progress = true;
                }
            }
            else {
                alert(data['message']);
            }
        }
    });
}


function status() {
    console.log('Status');
    if (!checking_progress) {
        ignore_count += 1;
        if (ignore_count > 10) {
            ignore_count = 0;
        } else {
            return;
        }
    }
    $.ajax({
        url:'/proxy_dl/status',
        type:'get',
        success:function (data) {
            data = JSON.parse(data);
            if (data['status'] === 'success') {
                var progress = data['progress'];
                var downloads = data['downloads'];
                $('#display *').remove();
                for (var i = 0; i < progress.length; i++) {
                    var link = progress[i];
                    var clone = $('#samples #progress').clone();
                    clone.find('#name').text(link.name);
                    clone.find('#progress-bar').attr({'style': 'width: '+link.progress+'%'}).text(link.progress+'%');
                    clone.appendTo('#display');
                }
                if (progress.length === 0) {
                    checking_progress = false;
                }
                for (var i = 0; i < downloads.length; i++) {
                    var link = downloads[i];
                    var clone = $('#samples #download').clone();
                    clone.find('#name').text(link.name);
                    clone.find('#size').text(link.size);
                    clone.find('#download-link').attr({'href':link.url});
                    clone.find('#proxy-link').attr({'href':link.proxy_url});
                    clone.find('#split-download').attr({'href':'/proxy_dl/split-download/'+link.id});
                    clone.appendTo('#display');
                }
            } else {
                alert(data['message']);
            }
        }
    });
}

$(function () {
    status();
    setInterval(status , 2500);
});
