$.ajax({
  url: '/proxy_dl/settings_api',
  type: 'get',
  success: function(data) {
    data = JSON.parse(data);
    if (data['status'] === 'success') {
      window.data = data;
      for (var key in data) {
          if (typeof data[key] === typeof false) {
            $('[name="' + key + '"]')[0].checked = data[key];
          } else {
            $('[name="' + key + '"]').val(data[key]);
          }
      }

    } else {
      toast(data['message']);
    }
  }
});



function save_settings () {
   var data = {};
   $('input[data-type="setting"]').each(function () {
       if ($(this).attr('type') === 'checkbox') {
           data[$(this).attr('name')] = $(this)[0].checked;
       }
       else if ($(this).attr('type') === 'number') {
           data[$(this).attr('name')] = parseInt($(this).val());
       } else {
           console.log(this);
           data[$(this).attr('name')] = $(this).val();
       }
   });
   console.log(data);
   $.ajax({
       url:'/proxy_dl/settings_api',
       type:'post',
       data: data,
       success:function (data) {
           data = JSON.parse(data);
           if (data['status'] === 'success') {
               alert('Settings Saved');
           } else {
               alert(JSON.stringify(data));
           }
       }
   });

}

