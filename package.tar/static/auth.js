$.ajax({
  url: '/auth/tokens',
  type: 'get',
  success: function(data) {
    data = JSON.parse(data);
    if (data['status'] === 'success') {
      window.data = data;
      reloadTokens();
    } else {
      toast(data['message']);
    }
  }
});

function reloadTokens() {
   $('#tokens *').remove();
   for (var i = 0; i < window.data.tokens.length; i++) {
   var token = window.data.tokens[i];
       var clone = $('#templates #token-template').clone();
       clone.find('#token').text(token.token);
       clone.find('.w3-check')[0].checked = token.is_admin;
       clone.find('.closebtn').attr('data-id', i);
       $('#tokens').append(clone);
   };
}

function deleteToken(e) {
   var id = parseInt($(e).attr('data-id'));
   var token = window.data['tokens'][id];
   if (confirm('Are you sure you want to delete this token?\n\n\''+token.token+'\'')) {
       window.data['tokens'].splice(id, 1);
       $(e).parents('li').slideUp(400, reloadTokens);
       reloadTokens();
   }
}

function addToken() {
   var token = $('[name="token"]').val();
   if (token.length === 0) {
       alert('Token can\'t be empity');
       return;
   }
   var is_admin = false;
//   alert(window.data.tokens.push)
   window.data.tokens.push({token:token, is_admin:is_admin});
   reloadTokens()
   $('[name="token"]').val('');
}

function toggleTokenState (e) {
   var id = parseInt($(e).parents('#token-template').find('.closebtn').attr('data-id'));
   window.data.tokens[id].is_admin = e.checked;
}


function saveChanges () {
   var data = {};
   data['tokens'] = JSON.stringify(window.data.tokens);
   console.log(data);
   $.ajax({
       url:'/auth/tokens',
       type:'post',
       data: data,
       success:function (data) {
           data = JSON.parse(data);
           if (data['status'] === 'success') {
               alert('Changes Saved');
           } else {
               alert(JSON.stringify(data));
           }
       }
   });

}
