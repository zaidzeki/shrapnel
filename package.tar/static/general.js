function toast(text) {
	alert(text);
}