function start() {
    $.ajax({
        url:'/uconvert/details',
        type:'get',
        data:{
            'url':$('[name=\'url\']').val()
        },
        success:function (data) {
            data = JSON.parse(data);
            if (data['status'] === 'success') {
            	var details = data['details'];
            	var options = [];
            	for (var i = 0; i < details.length; i++) {
            		var detail = details[i];
            		options.push($(document.createElement('option')).attr({
            			value:detail['id']
            		}).text(detail['resolution']+"."+detail['extension']+" == "+detail['size']));
            	};
        		var select = document.createElement('select');
        		$(options).each(function(i, option) {
        			$(select).append(option);
        		});
        		$('#display select').remove();
        		$(select).addClass('w3-select').prependTo('#display');
        		$('#display').slideDown();
            }
            else {
                alert(data['message']);
            }
        }
    });
}

function download() {
    $.ajax({
        url:'/uconvert/download',
        type:'post',
        data:{
            'url':$('[name=\'url\']').val(),
            'id':parseInt($('select').val())
        },
        success:function (data) {
            data = JSON.parse(data);
            if (data['status'] === 'success') {
            	toast('Download Started')
            }
            else {
                alert(data['message']);
            }
        }
    });
}

function status() {
    $.ajax({
        url:'/uconvert/status',
        type:'get',
        success:function (data) {
            data = JSON.parse(data);
            if (data['status'] === 'success') {
            	// toast('Status');
            	$('#list li').remove();
            	var downloads = data['downloads'];
            	for (var i = 0; i < downloads.length; i++) {
            		var download = downloads[i];
            		var clone = $('#samples #download').clone();
            		clone.find('#name').text(download['name']);
            		clone.find('#download-link').attr({'href':download['url']});
            		clone.appendTo('#list');
            	};
            	var progress = data['progress'];
            	for (var i = 0; i < progress.length; i++) {
            		var download = progress[i];
            		var clone = $('#samples #progress').clone();
            		clone.find('#name').text(download['name']);
            		clone.find('#progress-bar').attr({'style': 'width: '+download['progress']+'%;'}).text(download['progress']+' %');
            		clone.appendTo('#list');
            	};
            }
            else {
                alert(data['message']);
            }
        }
    });
}

$(function() {
	status();
	setInterval(status, 2500);
});