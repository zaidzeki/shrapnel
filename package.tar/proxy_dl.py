from flask import Blueprint, render_template, request, session, redirect
import requests
import json
import os
import math
import _thread
from nanorm import *
from app import resources, Link, save_history, DOWNLOAD_HOST
from auth import check_session, Token

''' Utils '''


class Downloader:
	@staticmethod
	def download(link):
		print("Downloading: " + link.url)
		# check owner directory exists
		if not os.path.exists('static/proxy_dl/' + link.owner):
			os.mkdir('static/proxy_dl/' + link.owner)
		link.filepath = '/static/proxy_dl/' + link.owner + '/' + link.name
		sess = requests.session()
		fp = open(link.filepath[1:], 'wb')
		req = sess.get(link.url, stream=True, allow_redirects=True)
		total_size = int(req.headers.get('Content-Length', -1))
		downloaded_size = 0
		# stream file content
		for data in req.iter_content(1024 * 1024 * 25):
			fp.write(data)
			fp.flush()
			if total_size > 0:
				downloaded_size += len(data)
				link.progress = (downloaded_size * 100) // total_size
				link.save()
		link.progress = 100
		link.save()
		fp.close()
		# Downloader.send_to_proxy(link)

	@staticmethod
	def send_to_proxy(link):
		user_id = Token.query().filter(token=link.owner).first().id
		resp = requests.post(
			DOWNLOAD_HOST + '/save_file',
			files={'file': open(link.filepath[1:], 'rb')},
			data={'user_id': user_id}
		).content
		resp = json.loads(str(resp, 'utf-8'))
		if resp['status'] == 'success':
			fragment_id = resp['fragment_id']
			resp = requests.get(DOWNLOAD_HOST + '/get_url/' + str(fragment_id)).content
			resp = json.loads(str(resp, 'utf-8'))
			if resp['status'] == 'success':
				link.proxy_url = DOWNLOAD_HOST + resp['url']
				link.progress = 100
				link.save()
		link.progress = 100
		link.save()

	@staticmethod
	def start_downloads_thread():
		downloading = []
		while True:
			for link in Link.query().filter(progress=100, operator='<').all():
				if link.id not in downloading:
					downloading += [link.id]
					_thread.start_new_thread(Downloader.download, (link,))
			time.sleep(2)


blueprint = Blueprint('proxy_dl', __name__, url_prefix='/proxy_dl')


@blueprint.route('/')
def index():
	if not check_session(session):
		save_history('proxy_dl.index', '', session)
		return redirect('/auth/login')
	save_history('proxy_dl.index', '', session)
	return render_template('proxy_dl/index.html', admin=check_session(session, is_admin=True), **resources)


@blueprint.route('/download', methods=['POST'])
def download():
	if not check_session(session):
		save_history('proxy_dl.download', 'Unauthorized Access')
		return json.dumps({
			"status": "Unauthorized",
			"message": "You are not authorized to add downloads"
		})
	if request.method == 'POST':
		url = request.form['url']
		name = request.form['name']
		if len(Link.query().filter(name=name, owner=session.get('owner')).all()) > 0:
			save_history(
				'proxy_dl.download',
				'Download "{}" from "{}" can\'t be added because another file with the same name exists'.format(name,
				                                                                                                url),
				session
			)
			return json.dumps({
				'status': 'File exists',
				'message': 'Another file with the same name already exists'
			})
		else:
			link = Link(name=name, url=url, owner=session.get('owner'))
			link.save()
			save_history('proxy_dl.download', 'Added download (ID:{}) "{}" from "{}"'.format(link.id, name, url),
			             session)
			return json.dumps({"status": "success"})


@blueprint.route('/status')
def status():
	if not check_session(session):
		save_history('proxy_dl.status', 'Unauthorized Access')
		return json.dumps({
			"status": "Unauthorized",
			"message": "You are not authorized to request status"
		})
	progress = []
	downloads = []
	for link in Link.query().filter(owner=session.get('owner')).all():
		if link.progress == 100:
			downloads.append({
				"id": link.id,
				"name": link.name,
				"size": get_size(link),
				"proxy_url": link.proxy_url,
				"url": link.filepath
			})
		else:
			progress.append({
				"name": link.name,
				"progress": link.progress
			})
	return json.dumps({
		"status": "success",
		"progress": progress,
		"downloads": downloads
	})


@blueprint.route('/split-download/<_id>')
def split_download(_id):
	# TODO library fs.mkdir(strict=False)  -- strict=return error if dir exists
	if not check_session(session):
		save_history('proxy_dl.split_download', 'Unauthorized Access')
		return redirect('/auth/login')
	config = json.load(open('config.json'))
	link = Link.query().filter(id=_id).first()
	if not os.path.exists('static/proxy_dl/' + link.owner + '/'):
		os.mkdir('static/proxy_dl/' + link.owner + '/')
	folder = 'static/proxy_dl/' + link.owner + '/' + str(link.id) + '/'
	if not os.path.exists(folder):
		os.mkdir(folder)
		fp = open(link.filepath[1:], 'rb')
		data = fp.read(config['splice_size'])
		i = 0
		while len(data) > 0:
			fpo = open(os.path.join(folder, str(i) + '_' + link.name), 'wb+')
			fpo.write(data)
			fpo.flush()
			fpo.close()
			i += 1
			data = fp.read(config['splice_size'])
		save_history(
			'proxy_dl.split_download',
			'Generated split download for (ID:{}) {}'.format(link.id, link.name),
			session
		)
	save_history('proxy_dl.split_download', 'Load split-download (ID:{}) {}'.format(link.id, link.name), session)
	files = [os.path.join(folder, file.name) for file in os.scandir(folder)]
	return render_template('proxy_dl/split-download.html', name=link.name, files=files, **resources)


@blueprint.route('/settings')
def settings():
	if not check_session(session, is_admin=True):
		save_history('proxy_dl.settings', 'Load settings')
		return redirect('/auth/login')
	save_history('proxy_dl.settings', 'Load settings', session)
	return render_template('proxy_dl/settings.html', **resources)


@blueprint.route('/settings_api', methods=['GET', 'POST'])
def settings_api():
	if not check_session(session, is_admin=True):
		save_history('proxy_dl.settings_api', 'Load Settings API')
		return json.dumps({
			"status": "Unauthorized",
			"message": "You are not authorized to use this api"
		})
	config = json.load(open('config.json'))
	if request.method == 'GET':
		tokens = []
		for token in Token.query().all():
			tokens.append({
				'token': token.token,
				'is_admin': token.admin
			})
		config['tokens'] = tokens
		config['status'] = 'success'
		save_history('proxy_dl.settings_api', 'Load settings', session)
		return json.dumps(config)
	else:
		keys = request.form.keys()
		for key in keys:
			value = request.form.get(key)
			if value.isnumeric():
				config[key] = int(value)
			elif value == 'true':
				config[key] = True
			elif value == 'false':
				config[key] = False
			else:
				config[key] = value
		fp = open('config.json', 'w+')
		json.dump(config, fp)
		fp.flush()
		fp.close()
		save_history('proxy_dl.settings_api', 'Saved settings', session)
		return json.dumps({'status': 'success'})


def get_size(link):
	size = os.stat(link.filepath[1:]).st_size
	if size < 1024:
		return str(math.ceil(size)) + " b"
	if size < 1024 * 1024:
		return str(math.ceil(size / 1024)) + " kb"
	if size < 1024 * 1024 * 1024:
		return str(math.floor(size / (1024 * 1024))) + " Mb"
	return str(math.floor(size / (1024 * 1024 * 1024))) + " Gb"


_thread.start_new_thread(Downloader.start_downloads_thread, ())
