import json
from nanorm import *
import datetime

set_db_name('markIV.db')
resources = json.load(open('resources.json'))
DOWNLOAD_HOST = 'http://localhost:9009'

''' Models '''


class Link(Model):
	name = CharField()
	url = CharField()
	proxy_url = CharField()
	progress = IntegerField()
	owner = CharField()
	filepath = CharField()


class Token(Model):
	token = CharField()
	admin = BooleanField()


class History(Model):
	component = CharField()
	action = CharField()
	owner = CharField()
	timestamp = DateTimeField()


def save_history(component, action, session=None):
	history = History(component=component, action=action)
	if session is not None:
		history.owner = session.get('owner')
	else:
		history.owner = "Unauthorized"
	history.timestamp = datetime.datetime.now()
	history.save()
