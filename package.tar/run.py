import os
from flask import Flask, render_template, session, redirect
import proxy_dl
import auth
from app import resources, save_history


class Config:
	DEBUG = True
	SECRET_KEY = 'NAHFSEGHSJHGAK'


app = Flask(__name__)
app.config.from_object(Config)
app.register_blueprint(proxy_dl.blueprint)
app.register_blueprint(auth.blueprint)


@app.route('/')
def index():
	if not auth.check_session(session):
		save_history('app.index', 'Unauthorized Acess')
		return redirect('/auth/login')
	save_history('app.index', 'Serving index', session)
	return render_template('index.html', admin=auth.check_session(session, is_admin=True), **resources)

if not os.path.exists('static/proxy_dl'):
	os.mkdir('static/proxy_dl')
#app.run("0.0.0.0", port=int(os.environ.get('PORT', 5885)))
